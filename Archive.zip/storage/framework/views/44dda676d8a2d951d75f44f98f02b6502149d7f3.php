<?php $__env->startSection('title', 'Encode Result'); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card border bg-white rounded-md mt-4 px-4 py-3">
            <h4>Add Candidate</h4>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group mt-1">
                    <label for="">Candidate name</label>
                    <select class="form-select" name="" id="">
                        <option value="">-Select candidate-</option>
                    </select>
                </div>
                <div class="form-group mt-1">
                    <label for="">Vote Count</label>
                    <input class="form-control" type="number" name="candidate" placeholder="Enter count...">
                </div>
                <button class="btn btn-primary mt-4">Submit</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/encodeResult.blade.php ENDPATH**/ ?>