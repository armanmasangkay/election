<div class="text-center text-muted mt-3">
<?php if(!Request::is('count*')): ?>
    <p>
        Logged in as <?php echo e(auth()->user()->name); ?> (<?php echo e(auth()->user()->username); ?>)
    </p>
    <p>
        Municipality: <?php echo e(auth()->user()->municipality); ?>

    </p>
<?php endif; ?>
    <div class="mt-5">
        <p>Developed by: SLSU-CCSIT Development Team</p>
        <p>Arman Masangkay | Benigno Ambus Jr.</p>
    </div>
</div>


<?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/layout/footer.blade.php ENDPATH**/ ?>