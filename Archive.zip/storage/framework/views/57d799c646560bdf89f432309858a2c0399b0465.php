<?php $__env->startSection('title', 'Edit Prencinct'); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<h4 class="my-4">Editting Precinct - <?php echo e($precinct->name); ?> </h4>

<div class="row justify-content-center">
    <div class="col col-md-6 col-lg-5">
        <form action="/precincts/update/<?php echo e($precinct->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            
            <div class="mb-3">
                <label for="precinct_name" class="form-label">New Name</label>
                <input class="form-control" type="text" name="precinct_name">
            </div>
        
            <div class="d-grid gap-2">
                <button class="btn btn-primary" type="submit">Submit</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/edit-precinct.blade.php ENDPATH**/ ?>