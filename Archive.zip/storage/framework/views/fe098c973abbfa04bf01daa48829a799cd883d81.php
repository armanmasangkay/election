<?php $__env->startSection('title', 'Precincts'); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<h4 class="mt-4">Add New Precinct</h4>
<div>
    <form action="/precincts/new" method="post">
        <?php echo csrf_field(); ?>
        <div class="d-flex align-items-end">
            <div class="me-2">
                <label class="form-label">Name</label>
                <input 
                type="text" 
                class="form-control <?php $__errorArgs = ['precinct_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                name="precinct_name" 
                placeholder="Enter Precinct Name">

                <?php $__errorArgs = ['precinct_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary">Add</button>
    </form>
</div>

</form>

<h4>Precincts in (<?php echo e(auth()->user()->municipality); ?>)</h4>

<table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $precincts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $precinct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td style="width: 80%"><?php echo e($precinct->name); ?></td>
            <td style="width: 20%">
                
                <a href="/precincts/edit/<?php echo e($precinct->id); ?>">Edit</a>

                <a 
                href="/precincts/delete/<?php echo e($precinct->id); ?>" 
                onclick="return confirm(
                    'Are you sure you want to delete <?php echo e($precinct->name); ?>?'
                )">
                    Delete
                </a>
            </td>
        </tr>   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td class="text-center">No precinct to show!</td>
        </tr>   
        <?php endif; ?>
      
      
    </tbody>
  </table>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/precincts.blade.php ENDPATH**/ ?>