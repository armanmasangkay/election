<?php $__env->startSection('title', 'Dashboard'); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<?php if($error): ?>
<div class="alert alert-success d-flex align-items-center my-4" role="alert">
    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
    <div>
     <?php echo e($error); ?>

    </div>
</div>

<?php else: ?>


<h4 class="my-4 text-center">Encode Result</h4>

<div class="alert alert-primary d-flex align-items-center" role="alert">
    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Info:"><use xlink:href="#info-fill"/></svg>
    <div>
      NOTE: You can leave the fields blank if it does not have any votes. Blank fields will default to zero.
    </div>
</div>

<?php if(! empty($errors->any())): ?>

<div class="alert alert-danger d-flex align-items-center" role="alert">
    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
    <div>
        An error occured while submitting votes. Please make sure that votes does not include decimal points or is a number.
    </div>
</div>
<?php endif; ?>

<form action="encode" method="post">
    <?php echo csrf_field(); ?>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3">
        <div class="col">
            <div class="card">
                <div class="card-header">
                <strong>Presidents</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $presidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $president): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($president->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($president->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4 mt-md-0">
                <div class="card-header">
                <strong>Vice Presidents</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $vice_presidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vice_president): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($vice_president->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($vice_president->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4 mt-lg-0">
                <div class="card-header">
                <strong>Senators</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $senators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $senator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($senator->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($senator->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>Governor</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $governors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($governor->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($governor->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>Vice-Governor</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $vice_governors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vice_governor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($vice_governor->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($vice_governor->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>Sangguniang Panlalawigan-First District</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $sg_firsts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sg_first): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($sg_first->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($sg_first->id); ?>" value="0">
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>Sangguniang Panlalawigan-Second District</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $sg_seconds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sg_second): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($sg_second->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($sg_second->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>House of Representatives-First District</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $hgFirsts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hgFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($hgFirst->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($hgFirst->id); ?>" value="0">
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>House of Representatives-Second District</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $hgSeconds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hgSecond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($hgSecond->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($hgSecond->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>Mayors</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $mayors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mayor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($mayor->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($mayor->id); ?>" value="0">
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>Vice-Mayors</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $vicemayors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vicemayor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($vicemayor->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($vicemayor->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card mt-4">
                <div class="card-header">
                <strong>Councilors</strong>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $councilors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $councilor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label for=""><?php echo e($councilor->name); ?></label>
                        <input type="number" class="form-control" name="candidate_<?php echo e($councilor->id); ?>" value="0" >
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No data found
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="d-grid gap-2">
        <button class="btn btn-primary mt-4 " type="submit" onclick="return confirm('PLEASE DOUBLE-CHECK VOTES BEFORE SUBMITTING! THIS ACTION CANNOT BE UNDONE!')">Submit</button>
    </div>
</form>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/encode-result.blade.php ENDPATH**/ ?>