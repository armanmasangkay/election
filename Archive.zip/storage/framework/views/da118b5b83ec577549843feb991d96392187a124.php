<?php $__env->startSection('title', 'Candidates'); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
<div class="alert alert-success d-flex align-items-center mt-4" role="alert">
  <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
  <div>
    <?php echo e(session('message')); ?>

  </div>
</div>
<?php endif; ?>

<h4 class="my-4">Accounts </h4>
<hr>
<table class="table">
    <thead>
      <tr>
        <th scope="col">Account Name</th>
        <th scope="col">Account Username</th>
        <th scope="col">Role</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->username); ?></td>
                <td><?php echo e($user->type); ?></td>
                <td>
                  <a href="/accounts/reset/<?php echo e($user->id); ?>" onclick="return confirm('Proceed to reset password?')">
                      Reset Password
                  </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td class='text-center' colspan="4">No candidate to show!</td>
            </tr>
        <?php endif; ?> 
    </tbody>
  </table>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/accounts.blade.php ENDPATH**/ ?>