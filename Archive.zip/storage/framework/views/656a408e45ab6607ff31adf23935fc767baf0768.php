<?php $__env->startSection('title', 'Dashboard'); ?>

<?php if(!Request::is('count*')): ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
<div class="alert alert-success d-flex align-items-center my-4" role="alert">
    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
    <div>
      <?php echo e(session('message')); ?>

    </div>
</div>
<?php endif; ?>

<?php if(Request::is('count*')): ?>
<div class="row justify-content-center pt-5 px-2">
    <div class="col-12 p-2 border bg-white shadow-sm">
        <h1 class="text-center">Municipality of <?php echo e($municipality); ?></h1>
    </div>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <div class="mt-4 mt-md-5">
            <div class="px-2 py-3 border bg-white"><h4 class="text-primary text-bold mb-1">Local Candidates</h4></div>
            <div class="border mt-1 bg-white">
                <table class="table table-condensed mb-0">
                    <tbody>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">Mayors</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <?php $__currentLoopData = $localCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($localCandidate['position'] === 'Mayor'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($localCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($localCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">Vice Mayors</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <?php $__currentLoopData = $localCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($localCandidate['position'] === 'Vice-Mayor'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($localCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($localCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">Councilors</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <?php $__currentLoopData = $localCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($localCandidate['position'] === 'Councilor'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($localCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($localCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="mt-4 mt-md-5">
            <div class="px-2 py-3 border bg-white"><h4 class="text-primary text-bold mb-1">Provincial Candidates</h4></div>
            <div class="mb-2 border mt-1 bg-white">
                <table class="table table-condensed mb-0">
                    <tbody>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">House of Representatives</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <tr>
                            <td colspan="2" class="px-4"><h5>First District</h5></td>
                        </tr>
                        <?php $__currentLoopData = $nationalCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationalCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nationalCandidate['position'] === 'House of Representatives-First District'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($nationalCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($nationalCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="border-bottom px-4"><h5>Second District</h5></td>
                        </tr>
                        <?php $__currentLoopData = $nationalCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationalCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nationalCandidate['position'] === 'House of Representatives-Second District'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($nationalCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($nationalCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">Governor</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <?php $__currentLoopData = $nationalCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationalCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nationalCandidate['position'] === 'Governor'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($nationalCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($nationalCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">Vice-Governor</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <?php $__currentLoopData = $nationalCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationalCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nationalCandidate['position'] === 'Vice-Governor'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($nationalCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($nationalCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">Board Members</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <tr>
                            <td colspan="2" class="border-bottom px-4"><h5>First District</h5></td>
                        </tr>
                        <?php $__currentLoopData = $nationalCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationalCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nationalCandidate['position'] === 'Sangguniang Panlalawigan-First District'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($nationalCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($nationalCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="border-bottom px-4"><h5>Second District</h5></td>
                        </tr>
                        <?php $__currentLoopData = $nationalCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationalCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nationalCandidate['position'] === 'Sangguniang Panlalawigan-Second District'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($nationalCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($nationalCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="mt-4 mt-md-5">
            <div class="px-2 py-3 border bg-white"><h4 class="text-primary text-bold mb-1">National Candidates</h4></div>
            <div class="mb-2 border mt-1 bg-white">
                <table class="table mb-0">
                    <tbody>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">Presidential Candidates</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <?php $__currentLoopData = $nationalCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationalCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nationalCandidate['position'] === 'President'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($nationalCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($nationalCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h4 class="text-center text-white mt-1">Senatorial Candidates</h4></td>
                        </tr>
                        <tr>
                            <th class="px-4">Candidates</th>
                            <th class="px-4">Vote Counts</th>
                        </tr>
                        <?php $__currentLoopData = $nationalCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationalCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nationalCandidate['position'] === 'Senators'): ?>
                            <tr>
                                <td class="px-4"><?php echo e($nationalCandidate['name']); ?></td>
                                <td class="px-4"><?php echo e($nationalCandidate['vote_count']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/new-dashboard.blade.php ENDPATH**/ ?>