<?php $__env->startSection('title', 'Live Count'); ?>

<?php $__env->startSection('content'); ?>
<input type="hidden" name="" id="position" value="<?php echo e($position); ?>">
<input type="hidden" name="" id="municipality" value="<?php echo e($municipality); ?>">
<div class="row justify-content-center align-items-center">
    <div class="col-12 col-md-8">
        <div class="mt-4 mt-md-5">
            <div class="px-2 py-3 border bg-white shadow"><h1 class="text-primary text-center text-bold mb-1">Local Candidates - <?php echo e(ucwords($municipality)); ?></h1></div>
            <div class="border mt-4 bg-white shadow">
                <table class="table table-condensed mb-0">
                    <tbody>
                        <tr>
                            <td colspan="2" class="border-bottom bg-dark"><h2 class="text-center text-white mt-1"><?php echo e($cleanPosition.'s'); ?></h2></td>
                        </tr>
                        <tr>
                            <th class="px-4"><h5>Candidates</h5></th>
                            <th class="px-4"><h5>Vote Counts</h5></th>
                        </tr>
                        <?php $__currentLoopData = $localCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localCandidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-4"><h4><?php echo e($localCandidate['name']); ?></h4></td>
                            <td class="px-4"><h4><?php echo e($localCandidate['vote_count']); ?></h4></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.live', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/live-count.blade.php ENDPATH**/ ?>