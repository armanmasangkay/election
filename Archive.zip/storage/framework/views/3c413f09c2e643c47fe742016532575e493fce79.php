<?php $__env->startSection('title', 'Reports'); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="row-">
    <div class="col-12">
    <div class="mt-5 px-2 py-3 border bg-white"><h4 class="text-primary text-center text-bold mb-1">Local Candidates - <?php echo e(ucwords(Auth::user()->municipality)); ?></h4></div>
        <div class="border bg-white mt-2">
            <table class="table mb-0">
                <tbody>
                    <tr>
                        <td class="bg-dark"><h5 class="text-white mt-1">Candidates</h5></td>
                        <?php $__currentLoopData = $precincts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $precinct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="bg-dark"><h5 class="text-white mt-1"><?php echo e($precinct->name); ?></h5></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr><td colspan="<?php echo e(count($precincts) + 1); ?>"><h5 class="mt-1">Mayors</h5></td></tr>
                    <tr>
                        <?php $__currentLoopData = $localCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($candidate['position'] === 'Mayor'): ?>
                            <tr>
                                <td><?php echo e($candidate['name']); ?></td>
                                <?php $__currentLoopData = $votes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $precincts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $precinct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(($vote['candidate_id'] === $candidate['id']) && $precinct->id === $vote['precinct_id']): ?>
                                    <td><?php echo e($vote['vote_count']); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr><td colspan="<?php echo e(count($precincts) + 1); ?>"><h5 class="mt-1">Vice-Mayors</h5></td></tr>
                    <tr>
                        <?php $__currentLoopData = $localCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($candidate['position'] === 'Vice-Mayor'): ?>
                            <tr>
                                <td><?php echo e($candidate['name']); ?></td>
                                <?php $__currentLoopData = $votes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $precincts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $precinct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(($vote['candidate_id'] === $candidate['id']) && $precinct->id === $vote['precinct_id']): ?>
                                    <td><?php echo e($vote['vote_count']); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr><td colspan="<?php echo e(count($precincts) + 1); ?>"><h5 class="mt-1">Councilors</h5></td></tr>
                    <tr>
                        <?php $__currentLoopData = $localCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($candidate['position'] === 'Councilor'): ?>
                            <tr>
                                <td><?php echo e($candidate['name']); ?></td>
                                <?php $__currentLoopData = $votes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $precincts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $precinct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(($vote['candidate_id'] === $candidate['id']) && $precinct->id === $vote['precinct_id']): ?>
                                    <td><?php echo e($vote['vote_count']); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/armanmasangkay/Documents/Documents/webproj/election/resources/views/report.blade.php ENDPATH**/ ?>